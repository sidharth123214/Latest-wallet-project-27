package cg;
import com.cg.bean.*;

import java.util.*;
public class NameComparator implements Comparator<Account> {

	@Override
	public int compare(Account o1, Account o2) {
		
	return o1.getAccountholder().compareTo(o2.getAccountholder());
		
	}

}
