package cg;
import com.cg.bean.*;
import java.util.*;

public class BalanceComparator implements Comparator<Account>{

	@Override
	public int compare(Account o1, Account o2) {
		// TODO Auto-generated method stub
		double diff=o1.getBalance()- o2.getBalance();
		if (diff>1)
			return 1;
		if (diff<1)
			return -1;
		else
		return 0;
	}

}
