package cg;

public class Validator {
	public int getSizeinMl(Size size)
	{	System.out.println(size+" "+size.getMI());
	return size.getMI();
	}
	
	public boolean validateNo(String data)
	{
		return data.matches("\\d+");
	}
	
	public boolean isPallindrome(String data) {
		StringBuilder sb = new StringBuilder(data);
		String reverseStr = sb.reverse().toString();
		return data.equals(reverseStr);
	}

}
