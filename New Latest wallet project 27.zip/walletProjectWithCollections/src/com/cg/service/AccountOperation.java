package com.cg.service;

import com.cg.bean.Account;
import com.sun.javafx.collections.MappingChange.Map;

public interface AccountOperation {
	public boolean addAccount(Account ob);
	public boolean deleteAccount(Account ob);
	public boolean findAccount(Account ob);
	public Map<Long,Account> getAllAccounts();
}
	


