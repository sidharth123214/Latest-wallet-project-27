package com.cg.service;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOimpl;
import com.cg.exception.InsuffecientFundException;
import com.sun.javafx.collections.MappingChange.Map;

public class AccountService implements Gst, Transaction{
	AccountDAO dao=new AccountDAOimpl();
	//implemented withdraw,deposit,transferMoney
	public boolean addAccount(Account ob) {
		return dao.addAccount(ob);
	}
	public boolean deleteAccount(Account ob) {
		return dao.deleteAccount(ob);
	}
	public Account findAccount(Long mobileno) {
		return dao.get(mobileno);
		
	}
	public Map<Long,Account> getAllAccounts() {
		return null;
	}

	

	@Override
	public double withdraw(Account ob, double amount) throws InsuffecientFundException {
		double new_balance=ob.getBalance()-amount;
		if(new_balance<1000.00)
		{
			new_balance=ob.getBalance();
			//System.out.println("Insufficient Balance");
			//throw new RuntimeException("insufficient insuffecientfund. cannot process withdrawal");
			throw new InsuffecientFundException("insuffecient fund. cannot process withdrawl",new_balance);
		}
		ob.setBalance(new_balance);
		return new_balance;
		// TODO Auto-generated method stub
		
	}

	@Override
	public double deposite(Account ob, double amount) {
		// TODO Auto-generated method stub
	double new_balance=ob.getBalance()+amount;
	ob.setBalance(new_balance);
		return new_balance;
	}

	@Override
	public double transferMoney(Account from, Account to, double amount) {
		// TODO Auto-generated method stub
		double newBal1=from.getBalance()-amount;
		double newBal2=to.getBalance()+amount;
		
		
		if(newBal1>1000)
		{
			from.setBalance(newBal1);
			
			to.setBalance(newBal2);
		}
		else
		{
			System.out.println("insuffecient fund try again");
		}
		return 0;
		
	}

	@Override
	public double calculateTax(double PCT, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean findAccount(Account ob) {
		// TODO Auto-generated method stub
		return false;
	}
	public int getBalance() {
		// TODO Auto-generated method stub
		return 0;
	}

	
	}


