package com.cg.pl;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;


import com.cg.bean.*;
import com.cg.exception.InsuffecientFundException;
import com.cg.service.AccountService;
import com.cg.service.Gst;
import com.cg.service.Validator;
public class MyWallet {
	

	
	
		
		 public static void main(String[] args) throws IOException, InsuffecientFundException {
				// TODO Auto-generated method stub
			 
			 	AccountService service=new AccountService();
			 
				Map<Long,Account> accmap=new TreeMap<Long,Account>();
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				String choice = "";
				
				while(true) {
					System.out.println("menu");
					System.out.println("==========================");
					System.out.println("1. create new account");
					System.out.println("2. print all accounts");
					System.out.println("3.withdraw from account");
					System.out.println("4.delete the account");
					System.out.println("5.transfer money");
					System.out.println("6.deposit money");
					System.out.println("10. exit");
					System.out.println("=================");
					System.out.println("enter your choice");
					choice = br.readLine();
					
					
					
					switch(choice) {
					case "1" : int id=0;
					           long mb=0L;
						       String ah="";
						       double bal=0.0;
						       System.out.println("enter mobile no.");
						       while(true)
						       {
						    	   String s_mb=br.readLine();
						    	   boolean ch =Validator.validateData(s_mb,Validator.mobilepattern);
		                           if(ch)
		                           {
		                        	   try
		                        	   {
		                        		   
										mb=Long.parseLong(s_mb);
										break;
		                        				   
		                        	 }
		                        	   catch(NumberFormatException e)
		                        	   {
		                        		   System.out.println("mobile no  must be numeric re enter");
		                        	   }
		                        	   }
		                           else
		                           {
		                        	   System.out.println("re enter mobile number in 10 digits");
		                           }
		                           System.out.println("Enter account holder name");
						       }
						       System.out.println("enter account holder");
		                           while(true)
							       {
							    	   String s_ah=br.readLine();
							    	   boolean ch1=Validator.validateData(s_ah,Validator.mobilepattern);
			                           if(ch1==true)
			                        	   {
			                        	   try
			                        	   {
			                        		   
											ah=s_ah;
											break;
			                        				   
			                        	 }
			                        	   catch(NumberFormatException e)
			                        	   {
			                        		   System.out.println("name must be string re enter");
			                        	   }
			                        	   }
			                           else {
			                        	   System.out.println("re enter name");
			                           }}
		                           //end of account holder while
			                           String s_ba = "";
			                           System.out.println("Balance");
			                           while(true)
			                           {
			                        	   s_ba=br.readLine();
			                        	 boolean  ch=Validator.validateData(s_ba,Validator.mobilepattern);
			                           
			                           if(ch)
		                        	   {
		                        	   try
		                        	   {
		                        		   
										bal=Double.parseDouble(s_ba);
										
		                        				   
		                        	   }
		                        	   catch(NumberFormatException e)
		                        	   {
		                        		   System.out.println("enter in numeric");
		                        	   }
		                        	   }
		                        	   else
		                        	   {
		                        		   System.out.println("enter in numeric");
		                        	   }
		                        	   
		                        	   if(bal>0)
		                        	   {
		                        		   Account ob=new Account(id,mb,ah,bal);
		                        		   accmap.put(ob.getMobile(),ob);
		                        		   break;
		                        	   }
		                        	   else
		                        	   {
		                        		   System.out.println("balance can't be less than zero");
		                        		   System.out.println("reenter the balance");
		                        	   }// end of balance while
		                        	   break;}
							       
		                        	   case "2":Collection<Account>vc=accmap.values();
		                        	            List<Account>acclist =new ArrayList<Account>(vc);
		                        	            
		                        	            
		                        	            for(Account o : acclist)
		                        	            {
		                        	            	System.out.println(o);
		                        	            }
		                        	            break;
		                        	            
		                        	     case "3" :System.out.println("enter account number ");
		                        	     long accid=Long.parseLong(br.readLine());
		                        	     System.out.println("enter amount");
		                        	     double am=Double.parseDouble(br.readLine());
		                        	     service.withdraw(accmap.get(accid),am);
		                        	     break;
		                        	     
		                        	     
		                        	     case "4" : System.out.println("enter account number ");
		                        	      accid=Long.parseLong(br.readLine());
		                                  service.deleteAccount(accmap.get(accid));
		                        	     break;
		                        	     
		                        	     
		                        	     case "5" :  System.out.println("enter from account number ");
		                        	      accid=Long.parseLong(br.readLine());
		                        	     System.out.println("enter to account no");
		                        	     long tcid=Long.parseLong(br.readLine());
		                        	     System.out.println("enter amount");
		                        	     double amt=Double.parseDouble(br.readLine());
		                        	     service.transferMoney(accmap.get(accid),accmap.get(tcid),amt);
		                        	     break;
		                        	     
		                        	     case "6" :System.out.println("enter account number ");
		                        	     long did=Long.parseLong(br.readLine());
		                        	     System.out.println("enter amount");
		                        	     double amo=Double.parseDouble(br.readLine());
		                        	     service.deposite(accmap.get(did),amo);
		                        	     break;
		                        	     
		                        	     case "10" : System.out.println("exiting program");
		                        	     System.exit(0);
		                        	     break;
		                        	     default:System.out.println("invalid choice");
		                        	   }}}}
					
		     
		                        	     
		                        	     
		                        	     
		                        	     
		                        	            
		                        	   
		                        	   
					
                                         					
		 
		 
