package com.cg.dao;
import java.util.*;

import com.cg.bean.Account;
import com.sun.javafx.collections.MappingChange.Map;

public class AccountDAOimpl implements AccountDAO {
	
	HashMap<Long, Account> accmap= new HashMap<Long,Account>();

	@Override
	public boolean addAccount(Account ob) {
		accmap.put(ob.getMobile(),ob);
		return true;
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(Account ob) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account findAccount(Long mobileno) {
		Account ob=accmap.get(mobileno);
		return ob;
	}

	@Override
	public Map<Long, Account> getAllAccounts() {
		// 
		return (Map<Long, Account>) accmap;
	}

	@Override
	public Account get(Long mobileno) {
		// TODO Auto-generated method stub
		return null;
	}}

	