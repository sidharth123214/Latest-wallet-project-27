package com.cg.dao;

import com.cg.bean.Account;
import com.sun.javafx.collections.MappingChange.Map;

public interface AccountDAO {
	public boolean addAccount(Account ob);
	public boolean updateAccount(Account ob);
	public boolean deleteAccount(Account ob);
	public Account findAccount(Long mobileno);
	public Map<Long,Account> getAllAccounts();
	public Account get(Long mobileno);
	
	

}
