package com.cg.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bean.Account;
import com.cg.exception.InsuffecientFundException;
import com.cg.service.AccountService;

class WalletTesting {

	@Test
	void withdrawTest() {
		
		
		AccountService ob=new AccountService();
		double amount=0;
		Account a=new Account();
		a.setBalance(5000);
		double new_balance=a.getBalance()-amount;
		try {
			assertTrue( ob.withdraw(a,3000)>1000);
		} catch (InsuffecientFundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
void depositTest() {
	AccountService ob=new AccountService();
	double amount=0;
	Account a=new Account();
	a.setBalance(5000);
	double new_balance=ob.getBalance()+amount;
	
		assertTrue( ob.deposite(a,3000)>5000);
	
	}
	
void transferMoney() {
	AccountService ob=new AccountService();
	double amount=0;
	Account a=new Account();
	Account b=new Account();
	a.setBalance(40000);
	b.setBalance(30000);
	double newBal1=a.getBalance()-10000;
	double newBal2=b.getBalance()+10000;
	assertequals( ob.transferMoney(a,b,amount));
	
	
	
	
	
	
}
	
}


