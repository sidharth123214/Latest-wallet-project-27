package cg;

public class Calculator {
	public int add(int a,int b)
	{ 
		int res=a+b;
		return res;
	}

}
