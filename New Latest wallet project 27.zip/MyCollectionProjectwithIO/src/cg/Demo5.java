package cg;
import java.util.*;

import org.omg.Messaging.SyncScopeHelper;

import java.io.*;
import com.cg.service.*;
import com.cg.bean.*;
import com.cg.bean.Account;

public class Demo5 {

	private static final Double Ob = null;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Map<Long,Account> accmap=new TreeMap<Long,Account>();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String choice = "";
		
		while(true) {
			System.out.println("menu");
			System.out.println("==========================");
			System.out.println("1. create new account");
			System.out.println("2. print all accounts");
			System.out.println("3. exit");
			System.out.println("enter your choice");
			choice = br.readLine();
			
			
			switch(choice) {
			case "1" : int id=0;
			           long mb=0L;
				       String ah="";
				       double bal=0.0;
				       System.out.println("enter mobile no.");
				       while(true)
				       {
				    	   String s_mb=br.readLine();
				    	   boolean ch1=Validator.validateData(s_mb,Validator.mobilepattern);
                           if(ch1==true)
                        	   {
                        	   try
                        	   {
                        		   
								mb=Long.parseLong(s_mb);
								break;
                        				   
                        	 }
                        	   catch(NumberFormatException e)
                        	   {
                        		   System.out.println("mobile no  must be numeric re enter");
                        	   }
                        	   }
                           else
                           {
                        	   System.out.println("re enter mobile number in 10 digits");
                           }
				 // end of mobile number while
                           
				        // accepting and validating account holder
                           System.out.println("Enter account holder name");
				       ah=br.readLine();
				       
				        //accepting and validating balance
				       System.out.println("enter initial balance");
				       String s_bal=br.readLine();
				       bal=Double.parseDouble(s_bal);
				       Account ob=new Account(id,mb,ah,bal);
				       accmap.put(ob.getMobile(),ob);
				       break;}
			case "2" :
				
				       Collection<Account> vc=accmap.values();
				       List<Account>acclist=new ArrayList<Account>(vc);
				       Collections.sort(acclist);
				       for(Account O:acclist)
				       {
				    	   System.out.println(O);
				    	   //service.printStatement
				       }
				
				break;
				
			case "3" :
				System.out.println("exiting program");
				System.exit(0);
				
				default:
					System.out.println("invalid choice");
			}
		}
					
		//System.out.println(accmap);
		//System.out.println(accmap.keySet());
		//System.out.println("===================");
		
		//Collection<Account> vc=accmap.values();
		//List<Account> acclist=new ArrayList<Account>(vc);
		//Collections.sort(acclist);
	   // for(Account o:acclist)
	   // {
	    	//System.out.println(o);
	    //}
	   // System.out.println("================= sort by name");
	   // Comparator nc=new NameComparator();
	   // Collections.sort(acclist,nc);
	   // for(Account o:acclist)
	   // {
	    //	System.out.println(o);
	    
		//}
	    //System.out.println("================= sort by balance");
	    //Comparator bc=new NameComparator();
	    //Collections.sort(acclist,bc);
	   // for(Account o:acclist)
	   // {
	    //	System.out.println(o);

	//}}}
	    

	}

	private static int parseInt(String s_id) {
		// TODO Auto-generated method stub
		return 0;
	}

}


