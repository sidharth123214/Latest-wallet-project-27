package com.cg.bean;

public class SavingAccount extends Account {
	private double interest;
	private final double MIN_bALANCE=1000.00;
	public SavingAccount() {
		
	}

}
